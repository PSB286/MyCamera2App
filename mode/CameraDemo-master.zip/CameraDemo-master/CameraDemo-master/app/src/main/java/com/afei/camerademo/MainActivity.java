package com.afei.camerademo;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.afei.camerademo.glsurfaceview.GLSurfaceCamera2Activity;
import com.afei.camerademo.glsurfaceview.GLSurfaceCameraActivity;
import com.afei.camerademo.surfaceview.SurfaceCamera2Activity;
import com.afei.camerademo.surfaceview.SurfaceCameraActivity;
import com.afei.camerademo.textureview.TextureCamera2Activity;
import com.afei.camerademo.textureview.TextureCameraActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkPermission();
    }

    public void startCameraActivity(View view) {
        Intent intent = null;
        switch (view.getId()) {
            case R.id.camera_btn1:
                intent = new Intent(this, SurfaceCameraActivity.class);
                break;
            case R.id.camera_btn2:
                intent = new Intent(this, TextureCameraActivity.class);
                break;
            case R.id.camera_btn3:
                intent = new Intent(this, GLSurfaceCameraActivity.class);
                break;
            case R.id.camera_btn4:
                intent = new Intent(this, SurfaceCamera2Activity.class);
                break;
            case R.id.camera_btn5:
                intent = new Intent(this, TextureCamera2Activity.class);
                break;
            case R.id.camera_btn6:
                intent = new Intent(this, GLSurfaceCamera2Activity.class);
                break;
        }
        startActivity(intent);
    }

    // 检查权限
    private void checkPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            String[] permissions = new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA};
            for (String permission : permissions) {
                if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, permissions, 200);
                    return;
                }
            }
        }
    }

    // 权限申请回调
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[]
            grantResults) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && requestCode == 200) {
            for (int i = 0; i < permissions.length; i++) {
                if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "请在设置中打开摄像头和存储权限", Toast.LENGTH_SHORT).show();
                    // 跳转设置
                    Intent intent = new Intent();
                    // 设置
                    intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                   // 包名
                    Uri uri = Uri.fromParts("package", getPackageName(), null);
                    intent.setData(uri);
                    // 启动
                    startActivityForResult(intent, 200);
                    return;
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == 200) {
            checkPermission();
        }
    }

}
