# 361Camera
An Android camera application
1. Support both JPEG and RAW data.
2. Support switch between front and back camera.
3. Support auto/off/force flash light.
4. Support delay to capture.
5. Support touch to focus.
6. Support HDR mode.
