package org.hunter.a361camera.base;

import android.app.Application;

public class CameraApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

    }

}
