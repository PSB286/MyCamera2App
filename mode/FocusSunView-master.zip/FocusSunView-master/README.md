# FocusSunView
自定义View - 相机预览点击聚焦框(带对焦动画，曝光调整)

效果如下

![image](https://github.com/LazyIonEs/FocusSunView/blob/master/gif/FocusSunView.gif?raw=true)
